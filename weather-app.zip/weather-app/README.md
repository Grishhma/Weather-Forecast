This app provides weather forecasts. The user-selected location's weather information is displayed. Users have the freedom to decide which city and which nation they want the weather forecast for. Forecasts are switchable between hourly, daily, and weekly. The app displays the current temperature together with the daily high and low. It shows a tiny description next to an icon that represents the current weather, such as "cloudy" or "sunny." Hourly forecasts can also use the same technology.

Using ReactJS, this dynamic web application was created. Utilize the Open Weather Map weather API. Pre-built react components were created using the Material-ui library. The node package manager was utilized to manage dependencies. Postman was used to validate the data APIs returned.

*** Assignment Question ***
Build a weather forecasting application using REACT
Display a 5-day weather forecast, where each day shows the high and low temperatures and an image for sunny/rainy/cloudy/snowy. Use fake, hard-coded data until you’ve got everything rendering correctly.
Add the ability to click on a day and see its hourly forecast. You can just maintain the current view in the top-level App state.
Add React Router to the project (npm install react-router) and add routes, such that / shows the 5-day forecast, and /[name-of-day] shows the hourly forecast for a particular day.
Sign up for a free API key from https://openweathermap.org/ (Links to an external site.)
Fetch a real 5-day forecast, and feed that data into your app.


# Getting Started with Create React App

This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## Available Scripts

In the project directory, you can run:

### `npm start`

Runs the app in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

The page will reload if you make edits.\
You will also see any lint errors in the console.

